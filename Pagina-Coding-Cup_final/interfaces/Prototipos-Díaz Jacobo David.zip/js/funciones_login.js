document.addEventListener("DOMContentLoaded",()=>{ 

  document.getElementById("btnRegistrar").addEventListener('click',
      (e)=>{
      location.replace('registroCoach.html');
  });

  document.getElementById("btnEntrar").addEventListener('click',
      (e)=>{
        if(document.getElementById("selRol").value==2){
          location.replace('Concursos.html');
        }else{
          location.replace('tablaEquipos.html');
        }
  });

});
    