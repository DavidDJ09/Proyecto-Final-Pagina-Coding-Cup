document.addEventListener("DOMContentLoaded", ()=>{
    if (!$.fn.dataTable.isDataTable('#tblEquipos')) {
        //$("selector").funcion();
        tabla=$("#tblEquipos").DataTable({
            columnDefs: [
                { orderable: false, targets: -1 }
            ],
            order: [[1, 'asc']],
        });
    } 
});