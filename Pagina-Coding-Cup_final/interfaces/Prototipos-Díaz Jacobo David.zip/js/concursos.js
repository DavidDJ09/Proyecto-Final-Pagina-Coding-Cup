document.addEventListener("DOMContentLoaded", ()=>{
    if (!$.fn.dataTable.isDataTable('#tblConcursos')) {
        //$("selector").funcion();
        tabla=$("#tblConcursos").DataTable({
            columnDefs: [
                { orderable: false, targets: -1 }
            ],
            order: [[1, 'asc']],
        });
    } 
});