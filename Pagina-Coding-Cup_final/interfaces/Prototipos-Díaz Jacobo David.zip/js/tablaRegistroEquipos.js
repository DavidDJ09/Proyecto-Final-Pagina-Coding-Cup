document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("btnAgregar").addEventListener('click', () => {
        window.location.replace('registroEquipos.html');
    });

    if (!$.fn.dataTable.isDataTable('#tblEquipos')) {
        //$("selector").funcion();
        tabla=$("#tblEquipos").DataTable({
            columnDefs: [
                { orderable: false, targets: -1 }
            ],
            order: [[1, 'asc']],
        });
    }
});
